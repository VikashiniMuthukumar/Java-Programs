class Student{
	private String studentId;
	private String name;

	Student(String studentId, String name){
		this.studentId=studentId;
		this.name=name;
	}
	public void setStudentId(String studentId){
		this.studentId=studentId;
	}
	public void setName(String name){
		this.name=name;
	}
	public String getStudentId(){
		return studentId;
	}
	public String getName(){
		return name;
	}
	public String toString(){
		return "StudentId:"+studentId+"\nName:"+name;
	}
}

class Courses{
	private String courseId;
	private String courseName;
	private Student[] student;
	private boolean[] attendance;
	
	Courses(String courseId,  String courseName, int size){
		this.courseId=courseId;
		this.courseName=courseName;
		this.student=new Student[size];
		this.attendance=new boolean[size];
	}
	public void enrollStudent(Student student){
		for(int i=0;i<student.length;i++){
			if(student[i]==null){
				student[i]=student;
				break;
			}
		}
	}
	public void markAttendance(String studentId, boolean isPresent){
	
	}
	public void displayAttendance(){
	
	}
	public void setCourseId(String courseId){
		this.courseId=courseId;
	}
	public void setCourseName(String courseName){
		this.courseName=courseName;
	}
	
	public String getCourseId(){
		return courseId;
	}
	public String getCourseName(){
		return courseName;
	}
	public String toString(){
		return "CourseId:"+courseId+"\nCourse Name"+courseName+"\n Students:"+student+"\nAttendance:"+attendance;
	}
}

class AttendanceSystem{
	private Student[] students;
	private Courses[] courses;
	private int studentCount;
	private int courseCount;

	AttendanceSystem(int studentCount, int courseCount, int courseSize, int studentSize){
		this.studentCount=studentCount;
		this.courseCount=courseCount;
		this.students=new Student[studentSize];
		this.courses=new Courses[courseSize];
	}
	public int setStudentCount(int studentCount){
		this.studentCount=studentCount;
	}
	public int setCourseCount(int courseCount){
		this.courseCount=courseCount;
	}
}

public class Test{
	public static void main(String[] args){
		Student s1=new Student("67","Vikashini");
		Student s2=new Student("68","Ravi");
		Student s3=new Student("69","Dev");

		Courses java=new Courses("BCS001", "Java", 5);
		Courses python=new Courses("BCS002", "Python", 6);

		java.enrollStudent(s1);
		java.enrollStudent(s2);
		java.enrollStudent(s3);
		python.enrollStudent(s1); 
		python.enrollStudent(s2);

	}
}
