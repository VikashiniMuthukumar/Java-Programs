import java.util.Scanner;
import java.util.ArrayList;
public class MissingNumbers{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		ArrayList<Integer> a=new ArrayList<>();
		for(int i=0;i<5;i++){
			a.add(sc.nextInt());
		}
		for(int i=0;i<5;i++){
		if(a.get(i)+1==a.get(i+1)){
			continue;
			}
		}
		for(int i=0;i<5;i++)
		System.out.print(a.get(i)+1+" ");
		
	}
}