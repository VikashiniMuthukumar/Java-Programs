import java.util.ArrayList;
class Test{
	public static void main(String args[]){
		ArrayList l=new ArrayList();
		int a=10;
		Integer i=new Integer(a);
		l.add(i);
		System.out.println(l);
	}
}