class T1 extends Thread{
	public void run(){
		for(int i=1;i<=5;i++){
			System.out.println("T1 -count: "+i);
			try{
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
class T2 extends Thread{
	public void run(){
		for(int i=1;i<=5;i++){
			System.out.println("T2 -count: "+i);
			try{
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
class T3 extends Thread{
	public void run(){
		for(int i=1;i<=5;i++){
			System.out.println("T3 -count: "+i);
			try{
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
class T4 extends Thread{
	public void run(){
		for(int i=1;i<=5;i++){
			System.out.println("T4 -count: "+i);
			try{
				Thread.sleep(2000);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
public class Task2{
	public static void main(String []args){
		T1 a=new T1();
		T2 b=new T2();
		T3 c=new T3();
		T4 d=new T4();
		a.start();
		try{
			a.join();
		}
		catch(InterruptedException e) {
				e.printStackTrace();
		}
		b.start();
		c.start();
		try{
			c.join();
		}
		catch(InterruptedException e) {
				e.printStackTrace();
		}
		d.start();
	}
}