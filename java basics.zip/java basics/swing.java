import javax.swing.JButton; 
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Sample extends Thread{
	public static void main(String args[]){
		JFrame frame=new JFrame("Sample ");
		frame.setSize(300,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//button creation
		JButton a=new JButton("Name");  
		a.setBounds(100,50,80,30);
		frame.getContentPane().add(a);
		frame.setLayout(null);

		// button function
		a.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				System.out.println("Hii Vikashini!!!");
			}
		});

		JButton b=new JButton("ID");  
		b.setBounds(100,100,80,30);
		frame.getContentPane().add(b);
		frame.setLayout(null);

		// button function
		b.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				System.out.println("727621BCS067");
			}
		});

		JButton c=new JButton("DOB");  
		c.setBounds(100,150,80,30 );
		frame.getContentPane().add(c);
		frame.setLayout(null);

		// button function
		c.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				System.out.println("16/06/2004");
			}
		});
		
		JButton d=new JButton("Place");  
		d.setBounds(100,200,80,30);
		frame.getContentPane().add(d);
		frame.setLayout(null);

		// button function
		d.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				System.out.println("Pollachi");
			}
		});
		frame.setVisible(true);

		

	}
}