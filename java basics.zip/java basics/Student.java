import java.util.Scanner;
class Student{
	int rollNo;
	String name;
	String emailId;

	Student(int roll, String name, String emailId){
		this.rollNo=roll;
		this.name=name;
		this.emailId=emailId;
	}
	void getRollNo(int roll){
		this.rollNo=roll;
	}
	void setName(String name){
		this.name=name;
	}
	void setEmailId(String emailId){
		this.emailId=emailId;
	}
	int getRollNo(){
		return rollNo;
	}
	String getName(){
		return name;
	}
	String getEmailId(){
		return emailId;
	}
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		Student a=new Student();
		int roll=sc.nextInt();
		String name =sc.next();
		sc.nextLine();
		String emailId=sc.nextLine ();
		
		System.out.println("Rollno:"+a.getRollNo());
		System.out.println("Name:"+a.getName());
		System.out.println("EmailId:"+a.getEmailId());
		}
}