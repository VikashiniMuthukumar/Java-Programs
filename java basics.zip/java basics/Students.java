class Student{
	private String studentId;
	private String name;
	Student(String studentId, String name){
		this.studentId=studentId;
		this.name=name;
	}
	public void setStudentId(String studentId){
		this.studentId=studentId;
	}
	public void setName(String name){
		this.name=name;
	}
	public String getStudentId(){
		return studentId;
	}
	public String getName(){
		return name;
	}
	public String toString(){
		return "StudentId:"+studentId+" "+"\nName:"+name;
	}
}
public class Students{
	public static void main(String[] args){
		Student s1=new Student("67","Vikashini");
		System.out.println(s1);
	}
}
