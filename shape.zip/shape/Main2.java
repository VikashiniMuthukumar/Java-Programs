import java.util.Scanner;
import java.math.RoundingMode;  
import java.text.DecimalFormat;

class Shape{
	 double area;
	public void computeArea(){
		area=0;
	}
}

class Circle extends Shape{
	double radius;
	public void computeArea(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radius :");
		radius= sc.nextDouble();
		area=3.14*radius*radius;
		System.out.println("Area of the circle is "+String.format("%.2f", area));  
	}
}

class Rectangle extends Shape{
	double length= 0;
	double breadth=0;
	Scanner sc=new Scanner(System.in);
	public void computeArea(){
		System.out.println("Enter the length:");
		 length= sc.nextDouble();
		System.out.println("Enter the breadth:");
		 breadth= sc.nextDouble();
		area=length*breadth;
		System.out.println("Area of the rectangle is "+String.format("%.2f", area));  
	}
}

class Triangle extends Shape{
	double base = 0;
	double height=0;
	Scanner sc=new Scanner(System.in);
	public void computeArea(){
		System.out.println("Enter the base :");
		base = sc.nextDouble();
		System.out.println("Enter the height:");
		height= sc.nextDouble();
		area=0.5*base *height;
		System.out.printf("Area of the triangle is"+String.format("%.2f", area));  
	}
}

public class Main2{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		Circle c=new Circle();
		Rectangle r=new Rectangle();
		Triangle t=new Triangle();
		System.out.println("Enter the shape \n1.Circle \n2.Rectangle \n3.Triangle");
		int choice= sc.nextInt();
		switch(choice){
			case 1:
				c.computeArea();
				break;
			case 2:
				r.computeArea();
				break;
			case 3:
				t.computeArea();;
				break;
			default:
				System.out.println("Invalid choice");
				break;
		}
	}
}