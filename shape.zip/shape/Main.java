import java.util.Scanner;
class GoldStall{
	GoldStall(){
		this.
public class Main{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Choose Stall Type \n1)Gold Stall \n 2)Premium Stall \n 3)Executive Stall");
		int choice=sc.nextInt();
		switch(choice){
			case 1:
				GoldStall();
				break;
			case 2:
				PremiumStall();
				break;
			case 3:
				ExecutiveStall();
				break;
			default:
				System.out.println("Invalid choice");
				break;
		}
	}
}
