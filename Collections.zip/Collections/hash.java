import java.util.Set;
import java.util.HashSet;
public class hash{
	public static void main(String args[]){
		Set s=new HashSet();
			s.add(48);
			s.add(1);
			s.add(14);
			s.add(16);
		Set s1=new HashSet();
			s1.add(98);
			s1.add(67);
			s1.add(1);
			s1.add(27);
		Set s2=new HashSet(s);
		s2.removeAll(s1);

		Set s3=new HashSet(s1);
		s3.removeAll(s);
   
		s2.addAll(s3);
		System.out.println(s2);
	}
}