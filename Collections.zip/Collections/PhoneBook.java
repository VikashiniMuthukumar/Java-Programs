import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.HashMap;
import java.util.TreeMap;
public class PhoneBook{
	public static void main(String args[]){
		Map<String,Long> phoneBook=new TreeMap();
		phoneBook.put("Vikash",9442252888L);
		phoneBook.put("Prasath",9442258882L);
		phoneBook.put("Dad",9442252781L);
		phoneBook.put("Mom",9865167888L);
		Set<Entry<String,Long>> e=phoneBook.entrySet();
		Iterator<Entry<String,Long>> itr=e.iterator();
		while(itr.hasNext()){
			Entry<String,Long> keyvalues=itr.next();
			String key=keyvalues.getKey();
			Long values=keyvalues.getValue();
			System.out.println("Name:"+key+"   "+"Phone Number :"+values);
		}
	}

}