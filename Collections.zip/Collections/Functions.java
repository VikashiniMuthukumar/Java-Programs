import java.util.Map;
import java.util.Set;
import java.util.Collection;
import java.util.HashMap;
public class Functions{
	public static void main(String args[]){
		Map<String,Long> phoneBook=new HashMap();
		phoneBook.put("Vikash",9442252888L);
		phoneBook.put("Prasath",9442258882L);
		phoneBook.put("Dad",9442252781L);
		phoneBook.put("Mom",9865167888L);
		Set key=phoneBook.keySet();
		System.out.println(key);
		Collection keyv=phoneBook.values();
		System.out.println(keyv);
		System.out.println(phoneBook);
	}
}