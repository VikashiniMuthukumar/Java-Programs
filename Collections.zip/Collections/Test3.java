import java.util.ArrayList;
import java.util. List;
import java.util.Comparator;


public class Test3 implements Comparator<String>{
	public int compare(String a1, String a2){
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiii");
		return a1.compareTo(a2);
	}
		
	public static void main(String args[]){
		List<String> a=new ArrayList();
		a.add("Vikashini");
		a.add("Ravi");
		a.add("Dev");
		
		Comparator<String> c=new Test3();
		a.sort(c);
		System.out.println(a);
	}
}		