import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

class Example{
	public static void main(String args[]){
		List a=new ArrayList();
		a.add(3);
		System.out.println(a);
		a.clear();
		System.out.println(a);
	}
}