import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Seta {

public static void main(String[] args) {

TreeSet<Integer> s= new TreeSet();

s.add(48);
s.add(1);
s.add(14);
s.add(16);

System.out.println(s);
System.out.println( s.ceiling(13));
System.out.println( s.floor(47));
System.out.println(s.pollFirst());
System.out.println(s);
System.out.println(s.pollLast());



}

}