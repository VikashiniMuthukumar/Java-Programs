import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Seet {
	public static void main(String[] args) {
		ArrayList<String> a= new ArrayList<>();
		Scanner s = new Scanner(System.in);
		String data= s.nextLine();// 4 hai hello haj kkkk
		String words[]= data.split(" ");
		int in=Integer.parseInt(words[0]);
		for(int i=1;i<words.length;i++)
			a.add( words[i] );

		for(int i=0;i<in;i++)
			System.out.print(a.get(i)+" ");
	}
  
}