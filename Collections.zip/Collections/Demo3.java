import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo3 {
	public static void main(String[] args) {
	try {
		int arr[]= new int[2];
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the data: ");
		int a=s.nextInt();
		int b=s.nextInt();
		int c = a/b;
		System.out.println("the ans : "+c);
		arr[2]=c;
		System.out.println("the arr : "+Arrays.toString(arr));
	}
	catch(InputMismatchException e1)
	{
		System.out.println("Enter integer type of input: "+e1);
	}
	catch(ArithmeticException e1)
	{
		System.out.println("cant div by 0 : "+e1);
	}
	catch (Exception e) {
		System.out.println("arr index pb: "+e);
	}

	System.out.println("bye all");
	}
}