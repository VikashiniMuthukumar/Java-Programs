import java.util.Scanner;
public class Student{
	public static void main(String args[])
		Scanner sc=new Scanner(System.in);
		System.out.println("Student Details!!");
		do{
		System.out.println("Enter a choice \n1.Create a student \n2.Edit student details \n3.Display the details of the student");
		int choice=sc.nextInt();
		Switch(choice){
			case 1:
				CreateStudent();
				break;
			case 2: 
				EditStudent();
				break;
			case 3:
				DisplayStudent();
				break;
			case 4:
				ExitingStudent();
				break;
			default:
				System.out.println("Enter a valid choice");
		}
		}while(choice!=4);
	}
}