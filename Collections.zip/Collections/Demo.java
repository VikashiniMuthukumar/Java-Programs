import java.util.Scanner;

public class Demo {

public static void main(String[] args) {
Scanner s = new Scanner(System.in);
System.out.println("Enter the data: ");
int a=s.nextInt();
int b=s.nextInt();
int c = a/b;
System.out.println("the ans : "+c);
System.out.println("bye all");

}

}