import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
public class Test1 {

	public static void main(String[] args) {
		 List<Integer>   a= new ArrayList();
		  a.add(5); 
		  a.add(23);
		  a.add(2233);
		  a.add(288);
		  a.add(26);
		 for(int i=0; i<a.size();i++)
			  System.out.println(a.get(i));
	}

}